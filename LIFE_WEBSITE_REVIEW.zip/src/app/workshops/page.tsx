import SiteHeader from "@/components/site-header";
import SiteFooter from "@/components/site-footer";

export default function WorkshopsPage() {
  return (
    <>
      <SiteHeader />
      <main className="mx-auto max-w-5xl px-6 py-14">
        <h1 className="text-4xl font-semibold tracking-tight">Workshops</h1>
        <p className="mt-4 text-lg text-zinc-700">
          Small-group, hands-on Mediterranean cooking experiences designed to be practical,
          joyful, and repeatable at home.
        </p>

        <div className="mt-10 grid gap-6 md:grid-cols-2">
          <div className="rounded-2xl border p-7">
            <h2 className="text-2xl font-semibold">What you'll learn</h2>
            <ul className="mt-4 list-disc pl-5 text-zinc-700 space-y-2">
              <li>How to cook 1-2 simple, real meals you can repeat weekly</li>
              <li>How to shop seasonally without overspending</li>
              <li>Why the table matters (stress, pace, belonging)</li>
              <li>How to build a weekly "table ritual" your family keeps</li>
            </ul>
          </div>

          <div className="rounded-2xl border p-7">
            <h2 className="text-2xl font-semibold">Format</h2>
            <div className="mt-4 space-y-2 text-zinc-700">
              <p><b>Group size:</b> 2-6 participants</p>
              <p><b>Length:</b> ~90 minutes</p>
              <p><b>Model:</b> Donation-based / RSVP required</p>
              <p><b>Includes:</b> Recipes, a habit plan, and a "host the table" guide</p>
            </div>
          </div>
        </div>

        <div className="mt-10 rounded-2xl border bg-zinc-50 p-7">
          <h2 className="text-2xl font-semibold">Request an invite</h2>
          <p className="mt-2 text-zinc-700">
            We're running limited pilot workshops while we refine the curriculum.
            Tell us where you are and what you want to learn.
          </p>

          <form action="/api/contact" method="post" className="mt-6 grid gap-3 md:grid-cols-2">
            <input name="name" required placeholder="Name" className="rounded-xl border px-4 py-3" />
            <input name="email" type="email" required placeholder="Email" className="rounded-xl border px-4 py-3" />
            <input name="city" placeholder="City (optional)" className="rounded-xl border px-4 py-3 md:col-span-2" />
            <textarea
              name="message"
              required
              placeholder="What would you love to learn? (pasta, sauces, weekly meal rhythm, hosting, etc.)"
              className="min-h-[120px] rounded-xl border px-4 py-3 md:col-span-2"
            />
            <button
              type="submit"
              className="rounded-xl bg-emerald-700 px-5 py-3 text-white hover:bg-emerald-800 md:col-span-2 md:justify-self-start"
            >
              Send Request
            </button>
          </form>
        </div>
      </main>
      <SiteFooter />
    </>
  );
}
